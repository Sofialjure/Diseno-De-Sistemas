package com.services;

public interface IUserService{

}
