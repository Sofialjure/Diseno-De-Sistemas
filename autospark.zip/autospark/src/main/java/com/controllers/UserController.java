package com.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.models.user;

@RestController
@RequestMapping("/users/autospark")
public class UserController {

    @GetMapping("/getAll")
    public List<user> getAll() {
        return null;
        //return service.findAll();
    }


}
