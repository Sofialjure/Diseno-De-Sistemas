package com.repositories;

public class UserRepository{

}
