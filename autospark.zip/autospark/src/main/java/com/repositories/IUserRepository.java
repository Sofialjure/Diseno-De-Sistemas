package com.repositories;

public interface IUserRepository {

}
